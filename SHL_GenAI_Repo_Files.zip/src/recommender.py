# Core recommendation logic lives here
