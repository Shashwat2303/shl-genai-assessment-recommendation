
# SHL GenAI Assessment Recommendation System

A GenAI-powered Retrieval-Augmented Generation (RAG) system for recommending
SHL Individual Test Solutions from hiring queries or job descriptions.

This repository demonstrates end-to-end AI engineering including
semantic retrieval, evaluation, and deployment.
